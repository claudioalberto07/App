
import 'class/Produto.dart';

class API {
  static var url = "http://appcompras.gestaoworks.com/rest.php";
  static var pathImage = "http://appcompras.gestaoworks.com/";
  static String baseToken = 'Basic qtDwW3MktkK0Oi8GtfSSGzBsrfcKayBH';

   List<Produto> _getProdutos(){

  }
}