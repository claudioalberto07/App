import 'file:///C:/Users/SESI/AndroidStudioProjects/app_loja/lib/class/Lojistas.dart';
import 'package:apploja/models/loja_model.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_staggered_grid_view/flutter_staggered_grid_view.dart';


class HomeTab extends StatelessWidget {
  LojaModel loja = LojaModel();

  @override
  Widget build(BuildContext context) {


    Widget _buildBodyBack() => Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            Color.fromARGB(255, 255, 128, 114),
            Color.fromARGB(255, 250, 0, 0)
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight
        )
      ),
    );

    return Stack(
      children: <Widget>[
        _buildBodyBack(),
        CustomScrollView(
          slivers: <Widget>[
            SliverAppBar(
              floating: true,
              snap: true,
              backgroundColor: Colors.transparent,
              elevation: 0.0,
              flexibleSpace: FlexibleSpaceBar(
                title: const Text("Lojas"),
                centerTitle: true,
              ) ,
            ),
            FutureBuilder<Lojista>(
              future: loja.getLojas(),
              builder: (context, data){
                if(!data.hasData){
                  return SliverToBoxAdapter(
                    child: Container(
                      height: 200.0,
                      alignment: Alignment.center,
                      child: CircularProgressIndicator(
                        valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                      ),
                    ),
                  );
                }
                else{
                  return SliverStaggeredGrid.count(
                      crossAxisCount: 1,
                    mainAxisSpacing: 1.0,
                    crossAxisSpacing: 1.0,
                  );
                }
              },

            )
          ],
        ),
      ],
    );
  }
}
