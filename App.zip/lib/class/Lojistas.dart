class Lojista {
  String status;
  List<Data> data;

  Lojista({this.status, this.data});

  Lojista.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    if (json['data'] != null) {
      data = new List<Data>();
      json['data'].forEach((v) {
        data.add(new Data.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    if (this.data != null) {
      data['data'] = this.data.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Data {
  String id;
  String nome;
  String imagem;
  String dinheiro;
  String cartao;
  String avaliacao;
  String aberta;
  String entrega;

  Data(
      {this.id,
        this.nome,
        this.imagem,
        this.dinheiro,
        this.cartao,
        this.avaliacao,
        this.aberta,
        this.entrega});

  Data.fromJson(Map<String, dynamic> json) {
    id = json['id'] ;
    nome = json['nome'];
    imagem = json['imagem'];
    dinheiro = json['dinheiro'];
    cartao = json['cartao'];
    avaliacao = json['avaliacao'];
    aberta = json['aberta'];
    entrega = json['entrega'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id as int;
    data['nome'] = this.nome as String;
    data['imagem'] = this.imagem as String;
    data['dinheiro'] = this.dinheiro as String;
    data['cartao'] = this.cartao as String;
    data['avaliacao'] = this.avaliacao as String;
    data['aberta'] = this.aberta as String;
    data['entrega'] = this.entrega as String;
    int id;
    String nome;
    return data;
  }
}
