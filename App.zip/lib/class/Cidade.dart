

class Cidade{
  Cidade(this.id, this.nome, this.estado);
  String id;
  String nome;
  String estado;

}