
import 'package:flutter/cupertino.dart';

class User{
  final String telefone;
  final String nome;
  final String senha;
  final String cpf;
  User({@required this.telefone, @required this.senha, @required this.nome, @required this.cpf});

  factory User.fromJson(Map<String, dynamic> json){
    return User(
      telefone: json["telefone"],
      nome: json["nome"],
      senha: json["senha"],
      cpf: json["cpf"]
    );
  }

}