

class Produto {
  String id;
  String nome;
  String valor;
  String valorPromocional;
  String unidade;
  String imagem;

  Produto({this.id,
        this.nome,
        this.valor,
        this.valorPromocional,
        this.unidade,
        this.imagem});

  factory Produto.fromJson(Map<String, dynamic> json) {
    return Produto(
    id: json['id'],
    nome: json['nome'],
    valor: json['valor'],
    valorPromocional: json['valor_promocional'],
    unidade: json['unidade'],
    imagem:  json['imagem'],
    );
  }
}
