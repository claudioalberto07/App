
class Bairro{
  String id;
  String nome;
  Bairro(this.id, this.nome);
}