class Banner {
  String banner1;
  String banner2;
  String banner3;


  Banner({this.banner1, this.banner2, this.banner3});

  Banner.fromJson(Map<String, dynamic> json) {
    banner1 = json['banner1'];
    banner2 = json['banner2'];
    banner3 = json['banner3'];

  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['banner1'] = this.banner1;
    data['banner2'] = this.banner2;
    data['banner3'] = this.banner3;
    return data;
  }
}
