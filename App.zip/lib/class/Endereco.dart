class Endereco {
  String id;
  String rua;
  String numero;
  String complemento;
  String systemBairroId;

  Endereco({this.id, this.rua, this.numero, this.complemento, this.systemBairroId});

  Endereco.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    rua = json['rua'];
    numero = json['numero'];
    complemento = json['complemento'];
    systemBairroId = json['system_bairro_id'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['rua'] = this.rua;
    data['numero'] = this.numero;
    data['complemento'] = this.complemento;
    data['system_bairro_id'] = this.systemBairroId;
    return data;
  }
}
