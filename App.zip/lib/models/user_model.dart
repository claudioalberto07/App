import 'package:flutter/cupertino.dart';
import 'package:scoped_model/scoped_model.dart';
import 'package:apploja/class/User.dart';
import 'package:http/http.dart' as http;
import 'dart:async';
import 'dart:convert';

class UserModel extends Model {
  bool isLoading = false;


  Future<User> createUser({ @required String nome, @required String senha,
                            @required String telefone, @required String cpf}) async{
    final response = await http.post(
        'http://appcompras.gestaoworks.com/rest.php',
        headers: {
          'Content-Type': 'application/json; charset=UTF-8',
          'authorization': 'Basic qtDwW3MktkK0Oi8GtfSSGzBsrfcKayBH'
        },
        body: jsonEncode( <String, String>{
          "class": "ServiceUsuario",
          "method": "GravarUsuario",
          "cpf": cpf,
          "nome": nome,
          "senha": senha,
          "email" : "CLAUDIO@gmail.com",
          "telefone" : telefone
        })
    );
    print(response.body);
    if(response.statusCode == 201){
      return User.fromJson(json.decode(response.body));
    } else{
      throw Exception("Usuário já cadastrado no sistema!");
    }
  }

  void criarConta(){

  }

  void signIn() async{
    isLoading = true;
    notifyListeners();

    await Future.delayed(Duration(seconds: 1));

    isLoading = false;
    notifyListeners();
  }
  void signOut(){}
  void recoverPass(){}
  bool isLoggedIn(){}
}