import 'file:///C:/Users/SESI/AndroidStudioProjects/app_loja/lib/class/Lojistas.dart';
import 'package:flutter/cupertino.dart';
import 'package:scoped_model/scoped_model.dart';
import 'package:http/http.dart' as http;
import 'dart:async';
import 'dart:convert';

class LojaModel extends Model {
  bool isLoading = false;

  Future<Lojista> getLojas() async{
    final response = await http.get(
        'http://appcompras.gestaoworks.com/rest.php?class=ServiceLoja&method=ListaLojasDisponiveis&cidade_id=5409',
        headers: {
          'Content-Type': 'application/json; charset=UTF-8',
          'authorization': 'Basic qtDwW3MktkK0Oi8GtfSSGzBsrfcKayBH'
        },
    );
    if(response.statusCode == 200){
      print(json.decode(response.body));
      return Lojista.fromJson(json.decode(response.body));
    } else{
      throw Exception("Nenhuma loja encontrada!");
    }
  }


}