import 'dart:convert';
import 'package:apploja/componentes/CustomAppBarItem.dart';
import 'package:apploja/API.dart';
import 'package:apploja/class/Produto.dart';
import 'package:apploja/componentes/custom_number_pick.dart';
import 'package:apploja/ui/MenuInfoLoja.dart';
import 'package:apploja/ui/MenuLateral.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/cupertino.dart';
import 'package:http/http.dart' as http;

class CarrinhoPage extends StatefulWidget {

  CarrinhoPage({this.jwt, this.idLoja });
  final String jwt;
  final String idLoja;
  var payload;

  @override
  _CarrinhoPageState createState() => _CarrinhoPageState();

}

class _CarrinhoPageState extends State<CarrinhoPage> {
  int _selectIndex = 0;

  void _selectTab(int index){
    setState(() {
      _selectIndex = index;
    });
  }
  TextEditingController buscarController = TextEditingController();
  final FocusNode myFocusNodeBuscar = FocusNode();
  ScrollController controller = ScrollController();
  bool closeTopContainer = false;
  double topContainer = 0;

  List<Widget> listCardLojas = [];
  Map<String, dynamic> _mapInfoLoja = {};
  List<dynamic> _listProdutos = [];


  Future<void> _fetchProdutos() async {
    try {
      final response = await http.post(
        API.url + '?class=ServiceProduto&method=ListaInfoLojaProdutosDisponiveis&loja=${widget.idLoja}',
        headers: {
          'authorization': 'Bearer ${widget.jwt}',
          'Accept': 'application/json',
          'Content-Type': 'application/json; charset=UTF-8',
        },
      );
      if (response.statusCode == 200) {
        Map<dynamic, dynamic> retorno = json.decode(response.body)["data"];
        List<dynamic> tempProdutos = retorno["produtos"];

        setState(() {
          _listProdutos = retorno["produtos"];
        });
        return;
      }
    } on Exception catch(_){
    }
  }

  Future<Widget> buildInfoCard(Map mapInfoLoja) async {
    return Container(
      height: 120.0,
      margin: const EdgeInsets.symmetric(vertical: 5.0, horizontal: 20.0),
      child: new Stack(
        children: <Widget>[
          Container(
              height: 124.0,
              alignment: FractionalOffset.centerLeft,
              decoration: new BoxDecoration(
                color: Colors.black12,
                shape: BoxShape.rectangle,
                borderRadius: new BorderRadius.circular(8.0),
                boxShadow: <BoxShadow>[
                  new BoxShadow(
                    color: Colors.black12,
                    blurRadius: 10.0,
                    offset: new Offset(0.0, 10.0),
                  ),
                ],
              ),
              child: Row(
                children: <Widget>[
                  Column(
                    children: <Widget>[
                      Container(
                        padding: EdgeInsets.only(left: 10, top: 10, bottom: 10),
                        child: CircleAvatar(
                          backgroundImage: NetworkImage(
                              API.pathImage + mapInfoLoja["imagem"] == null ?
                              'imagens/google.png':  API.pathImage + mapInfoLoja["imagem"] ),
                          backgroundColor: Colors.brown,
                          child: Text(''),
                          radius: 50.0,
                        ),
                      ),
                    ],
                  ),
                  Divider(),
                  Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: <Widget>[
                      Padding(
                        padding: EdgeInsets.only(left: 2, top: 10, bottom: 2, ),
                        child:Text(
                          mapInfoLoja["nome"],
                          style: TextStyle(
                              fontFamily: "WorkSansSemiBold",
                              fontSize: 16.0,
                              color: Colors.black
                          ),
                        ),
                      ),
                      Padding(
                          padding: EdgeInsets.only(left: 0, top: 2, bottom: 2),
                          child: Row(
                            children: <Widget>[
                              Text("STATUS: "),
                              Text(mapInfoLoja["aberta"] == "S" ? "Aberto": "Fechado"),
                            ],
                          )
                      ),
                      Padding(
                          padding: EdgeInsets.only(left: 0, top: 2, bottom: 2),
                          child: Row(
                            children: <Widget>[
                              Text("Entrega: "),
                              Text(mapInfoLoja["entrega"] == "C" ? mapInfoLoja["informacoesentrega"]: "Fechado"),
                            ],
                          )
                      ),
                      Padding(
                          padding: EdgeInsets.only(left: 0, top: 2, bottom: 2),
                          child: Row(
                            children: <Widget>[
                              Text(mapInfoLoja["mensagemfuncionamento"]),
                            ],
                          )
                      ),
                    ],
                  ),
                ],
              )
          ),
        ],
      ),
    );
  }

  Widget buildCardProduto(index)  {
    return Container(
        height: 120,
        margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 5),
        decoration: BoxDecoration(
            borderRadius: BorderRadius.all(Radius.circular(20.0)),
            color: Colors.white,
            boxShadow: [
              BoxShadow(
                  color: Colors.black.withAlpha(100),
                  blurRadius: 10.0
              ),
            ]),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10.0, vertical: 10),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Container(
                    height: 80,
                    width: 80,
                    decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        image: DecorationImage(
                            fit: BoxFit.cover,
                            image: NetworkImage( API.pathImage + _listProdutos[index]["imagem"])
                        )
                    ),
                  ),

                ],

              ),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 5),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(
                    _listProdutos[index]["nome"],
                    style: const TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.bold),
                  ),
                  Text(
                    _listProdutos[index]["unidade"] == "U" ? "Unidade": "100g",
                    style: const TextStyle(
                        fontSize: 10,
                        fontWeight: FontWeight.bold),
                  ),
                  Divider(),
                  Row(
                    children: <Widget>[
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(_listProdutos[index]["valor_promocional"] == "null" ?
                          "--R\$ ${_listProdutos[index]["valor"]}--": "R\$ ${_listProdutos[index]["valor"]}",
                            style: const TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.bold),
                          ),
                          Text(_listProdutos[index]["valor_promocional"] != "null" ?
                          "R\$ ${ _listProdutos[index]["valor_promocional"]}": "" ,
                            style: const TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.bold),
                          ),
                        ],
                      ),
                    ],
                  ),
                ],
              ),
              Expanded(
                child: Container(),
              ),

              Padding(
                padding: EdgeInsets.only(left: 5),
                child: Column(
                  children: <Widget>[
                    SizedBox(
                      height: 35,
                      width: 115,
                      child: CustomNumberPicker(
                        min: 0,
                        max: 1000,
                        onChange: (number) {
                          print("Mudei");
                        },
                      ),
                    ),
                    RaisedButton(
                      onPressed: () {},
                      child: const Text('Adicionar', style: TextStyle(fontSize: 16)),
                    ),
                  ],
                ),
              ),

            ],
          ),
        )
    );
  }

  @override
  void initState() {
    super.initState();
    _fetchProdutos();

    controller.addListener(() {
      double value = controller.offset/119;
      setState(() {
        topContainer = value;
        closeTopContainer = controller.offset > 50;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    final Size size = MediaQuery.of(context).size;
    final double categoryHeight = size.height*0.30;

    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.white,
        drawer: Drawer(child: MenuLateral(widget.jwt)),
        endDrawer: Drawer(child: MenuInfoLoja(_mapInfoLoja),),
        appBar: AppBar(
          elevation: 0,
          backgroundColor: Colors.blue,
          actions: <Widget>[
          ],
        ),
        bottomNavigationBar: CustomBottomAppBar(
          onTabSelected: _selectTab,
          items: [
            CustomAppBarItem(icon: Icons.location_on),
            CustomAppBarItem(icon: Icons.home),
            CustomAppBarItem(icon: Icons.shopping_cart),
          ],
        ),
        body: Container(
          height: size.height,
          child: Column(
            children: <Widget>[
              const SizedBox(
                height: 10,
              ),
              AnimatedOpacity(
                duration: const Duration(milliseconds: 200),
                opacity: closeTopContainer?0:1,
                child: AnimatedContainer(
                    duration: const Duration(milliseconds: 100),
                    width: size.width,
                    alignment: Alignment.topCenter,
                    height: closeTopContainer?0:categoryHeight,

                    child: Container()
                ),
              ),

              Expanded(
                child: ListView.builder(
                    controller: controller,
                    itemCount: _listProdutos.length,
                    physics: BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics()),
                    itemBuilder: (context, index) {
                      double scale = 1.0;
                      if (topContainer > 0.5) {
                        scale = index + 0.5 - topContainer;
                        if (scale < 0) {
                          scale = 0;
                        } else if (scale > 1) {
                          scale = 1;
                        }
                      }
                      return buildCardProduto(index);
                    }
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
