import 'dart:convert';
import '../API.dart';
import 'package:apploja/componentes/CustomAppBarItem.dart';
import 'package:apploja/ui/LojaPage.dart';
import 'package:apploja/ui/MenuLateral.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/cupertino.dart';
import 'package:http/http.dart' as http;

class HomePage extends StatefulWidget {

  HomePage({this.jwt, this.onTapMenu});
  final String jwt;
  final Function onTapMenu;
  var payload;

  @override
  _HomePageState createState() => _HomePageState();

}

class _HomePageState extends State<HomePage> {
  var URL = API.url;
  var pathImage = API.pathImage;

  int _selectIndex = 0;

  void _selectTab(int index){
    setState(() {
      _selectIndex = index;
    });
  }
  TextEditingController buscarController = TextEditingController();
  final FocusNode myFocusNodeBuscar = FocusNode();
  final CategoriesScroller categoriesScroller = CategoriesScroller();
  ScrollController controller = ScrollController();
  bool closeTopContainer = false;
  double topContainer = 0;

  List<Widget> listCardLojas = [];
  dynamic listBanners = [];

  Future<List> fetchLojas(String jwt) async {
    try {
      final response = await http.post(
        API.url + '?class=ServiceLoja&method=ListaLojasBannersDisponiveis',
        headers: {
          'authorization': 'Bearer $jwt',
          'Accept': 'application/json',
          'Content-Type': 'application/json; charset=UTF-8',
        },
      );
      if (response.statusCode == 200) {

        Map<String, dynamic> retorno = {"lojas": json.decode(response.body)["data"]["loja"]};
        return retorno["lojas"];
      }
    } on Exception catch(_){
    }
  }

  Future<List<String>> fetchBanners() async {
    try {
      final response = await http.post(
        API.url + '?class=ServiceLoja&method=ListaLojasBannersDisponiveis',
        headers: {
          'authorization': 'Bearer ${widget.jwt}',
          'Accept': 'application/json',
          'Content-Type': 'application/json; charset=UTF-8',
        },
      );
      if (response.statusCode == 200) {
        Map<String, dynamic> retorno = json.decode(response.body)["data"]["banner"];
        List<String> listTemp = [];

        retorno.forEach((key, value) {
          listTemp.add(value);
        });
        return listTemp;
      }
    } on Exception catch(_){
    }
  }

  Future<List<dynamic>> _buscaLojas(String jwt, String loja) async {
    try {
      final response = await http.post(
        API.url + '?class=ServiceLoja&method=BuscaLojasBannersDisponiveis&loja=$loja',
        headers: {
          'authorization': 'Bearer $jwt',
          'Accept': 'application/json',
          'Content-Type': 'application/json; charset=UTF-8',
        },
      );
      if (response.statusCode == 200) {
        List jsonresponde = json.decode(response.body)["data"]["loja"];
        return jsonresponde;
      }
    } on Exception catch(_){
      List<String> status = ["Não foi possivel conectar a internet. Tente novamente mais tarde!"];
      return status;
    }
  }

  void cardBuscaLoja(String loja) async {
    List<dynamic> responseList = await _buscaLojas(widget.jwt, loja);
    List<Widget> listItems = [];
    responseList.forEach((infoLoja) {
      listItems.add(Container(
          height: 150,
          margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
          decoration: BoxDecoration(
              borderRadius: BorderRadius.all(Radius.circular(20.0)),
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                    color: Colors.black.withAlpha(100),
                    blurRadius: 10.0
                ),
              ]),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10.0, vertical: 10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: <Widget>[
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Container(
                      height: 60,
                      width: 60,
                      decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          image: DecorationImage(
                              fit: BoxFit.cover,
                              image: NetworkImage(
                                pathImage + infoLoja["imagem"],
                              )
                          )
                      ),
                    ),

                  ],

                ),
                const SizedBox(
                  height: 30,
                  width: 15,
                ),

                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      infoLoja["nome"],
                      style: const TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.bold),
                    ),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Icon(
                            Icons.star,
                            color: Colors.yellow,
                            size: 15.0
                        ),
                        Icon(
                            Icons.star,
                            color: Colors.yellow,
                            size: 15.0
                        ),
                        Icon(
                            Icons.star,
                            color: Colors.yellow,
                            size: 15.0
                        ),
                        Icon(
                            Icons.star,
                            color: Colors.yellow,
                            size: 15.0
                        ),
                        Icon(
                            Icons.star,
                            color: Colors.yellow,
                            size: 15.0
                        ),
                      ],
                    ),

                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Icon(
                          infoLoja["cartao"] == "s" ? Icons.remove : Icons.credit_card,
                          size: 15.0,
                        ),
                        Icon(
                          infoLoja["dinheiro"] == "s" ? Icons.money_off: Icons.attach_money,
                          size: 15.0,
                        )
                      ],
                    ),
                    Row(
                      children: <Widget>[
                        Text(infoLoja["entrega"] == "C" ? "Entrega Grátis": "R\$ 5,0" ),
                      ],
                    )
                  ],
                ),
              ],
            ),
          )));
    });
    setState(() {
      listCardLojas = listItems;
    });
  }

  Future<List<Widget>> cardLoja()  async {
    List<dynamic> responseList = await fetchLojas(widget.jwt);
    List<Widget> listItems = [];
    responseList.forEach((infoLoja) {
      listItems.add(
        GestureDetector(
          onTap: (){
            Navigator.push(context, MaterialPageRoute(builder: (context) => LojaPage(jwt: widget.jwt, idLoja: infoLoja["id"], )));
          },
          child:  Container(
              height: 150,
              margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.all(Radius.circular(20.0)),
                  color: Colors.white,
                  boxShadow: [
                    BoxShadow(
                        color: Colors.black.withAlpha(100),
                        blurRadius: 10.0
                    ),
                  ]),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10.0, vertical: 10),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Container(
                          height: 60,
                          width: 60,
                          decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              image: DecorationImage(
                                  fit: BoxFit.cover,
                                  image: NetworkImage(pathImage + infoLoja["imagem"])
                              )
                          ),
                        ),

                      ],

                    ),
                    const SizedBox(
                      height: 30,
                      width: 15,
                    ),

                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          infoLoja["nome"],
                          style: const TextStyle(
                              fontSize: 15,
                              fontWeight: FontWeight.bold),
                        ),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Icon(
                                Icons.star,
                                color: Colors.yellow,
                                size: 15.0
                            ),
                            Icon(
                                Icons.star,
                                color: Colors.yellow,
                                size: 15.0
                            ),
                            Icon(
                                Icons.star,
                                color: Colors.yellow,
                                size: 15.0
                            ),
                            Icon(
                                Icons.star,
                                color: Colors.yellow,
                                size: 15.0
                            ),
                            Icon(
                                Icons.star,
                                color: Colors.yellow,
                                size: 15.0
                            ),
                          ],
                        ),

                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Icon(
                              infoLoja["cartao"] == "s" ? Icons.remove : Icons.credit_card,
                              size: 15.0,
                            ),
                            Icon(
                              infoLoja["dinheiro"] == "s" ? Icons.money_off: Icons.attach_money,
                              size: 15.0,
                            )
                          ],
                        ),
                        Row(
                          children: <Widget>[
                            Text(infoLoja["entrega"] == "C" ? "Entrega Grátis": "R\$ 5,0" ),
                          ],
                        )
                      ],
                    ),
                  ],
                ),
              )
          ),
        )
      );
    });
    setState(() {
      listCardLojas = listItems;
    });
    return listItems;
  }

  @override
  void initState() {
    super.initState();
    cardLoja();

    controller.addListener(() {
      double value = controller.offset/119;
      setState(() {
        topContainer = value;
        closeTopContainer = controller.offset > 50;
      });
    });
  }
  ListView _listViewBanner(List<String> listBanners){
    return ListView.builder(
      itemCount: listBanners.length,
      scrollDirection: Axis.horizontal,
      reverse: true,
      itemBuilder:(context, index) {
        print("Banner " + listBanners[index]);
          return Container(
            width: 300,
            margin: EdgeInsets.only(right: 10, left:20.0),
            decoration: BoxDecoration(
                color: Colors.blue.shade400,
                borderRadius: BorderRadius.all(Radius.circular(20.0)),
                image: DecorationImage(
                    fit: BoxFit.fill,
                    image: NetworkImage(API.pathImage + "${listBanners[index]}")
                )
            ),
          );

        },
    );
  }

  @override
  Widget build(BuildContext context) {
    final Size size = MediaQuery.of(context).size;
    final double categoryHeight = size.height*0.30;
    final double categoryHeight2 = MediaQuery.of(context).size.height * 0.30 - 50;

    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.white,
        drawer: Drawer(
          child: MenuLateral(widget.jwt)
        ),
        appBar: AppBar(
          elevation: 0,
          backgroundColor: Colors.blue,
          actions: <Widget>[
            IconButton(
              icon: Icon(
                  Icons.location_on,
                  color: Colors.white
              ),
              onPressed: () {},
            )
          ],
        ),
        bottomNavigationBar: CustomBottomAppBar(
          onTabSelected: _selectTab,
          items: [
            CustomAppBarItem(icon: Icons.list),
            CustomAppBarItem(icon: Icons.home),
            CustomAppBarItem(icon: Icons.person),
          ],
        ),
        body: Container(
          height: size.height,
          child: Column(
            children: <Widget>[
              const SizedBox(
                height: 10,
              ),
              AnimatedOpacity(
                duration: const Duration(milliseconds: 200),
                opacity: closeTopContainer?0:1,
                child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    width: size.width,
                    alignment: Alignment.topCenter,
                    height: closeTopContainer?0:categoryHeight,
                    child: FutureBuilder<List<String>>(
                      future: fetchBanners(),
                      builder: (BuildContext context, AsyncSnapshot<dynamic> snapshot) {
                        switch (snapshot.connectionState) {
                          case ConnectionState.none:
                            return Center(child: Text(snapshot.error));
                          case ConnectionState.waiting:
                            return Center(child: CircularProgressIndicator());
                          default:
                            if (snapshot.hasError)
                              return Center(child: Text(snapshot.error));
                            else
                            return _listViewBanner(snapshot.data);
                        }
                      },
                    )

                ),
              ),

              Card(
                elevation: 2.0,
                color: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8.0),
                ),
                child: Container(
                  width: 320.0,
                  height: 50.0,
                  child: Column(
                    children: <Widget>[
                      Padding(
                        padding: EdgeInsets.only(top: 0.0, bottom: 0.0, left: 10.0, right: 5.0),
                        child: TextFormField(
                          focusNode: myFocusNodeBuscar,
                          controller: buscarController,
                          keyboardType: TextInputType.text,
                          style: TextStyle(
                              fontFamily: "WorkSansSemiBold",
                              fontSize: 16.0,
                              color: Colors.black
                          ),
                          decoration: InputDecoration(
                            border: InputBorder.none,
                            hintText: "Buscar Loja",
                            hintStyle: TextStyle(fontFamily: "WorkSansSemiBold", fontSize: 17.0),

                            suffixIcon: MaterialButton(
                              highlightColor: Colors.transparent,
                              splashColor: Colors.blue,
                              child: Padding(
                                padding: EdgeInsets.only(left: 100),
                                child: Icon(
                                  Icons.search,
                                  color: Colors.black,
                                  size: 22.0,
                                ),
                              ),
                              onPressed: (){
                                cardBuscaLoja(buscarController.text);
                              },
                            )
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),



              Expanded(
                  child: ListView.builder(
                      controller: controller,
                      itemCount: listCardLojas.length,
                      physics: BouncingScrollPhysics(),
                      itemBuilder: (context, index) {
                        double scale = 1.0;
                        if (topContainer > 0.5) {
                          scale = index + 0.5 - topContainer;
                          if (scale < 0) {
                            scale = 0;
                          } else if (scale > 1) {
                            scale = 1;
                          }
                        }
                        return Opacity(
                          opacity: scale,
                          child: Transform(
                            transform:  Matrix4.identity()..scale(scale,scale),
                            alignment: Alignment.topRight,
                            child: Align(
                                heightFactor: 0.7,
                                alignment: Alignment.topCenter,
                                child: listCardLojas[index]
                            ),
                          ),
                        );
                      })
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class CategoriesScroller extends StatelessWidget {
  const CategoriesScroller();
  @override
  Widget build(BuildContext context) {
    final double categoryHeight = MediaQuery.of(context).size.height * 0.30 - 50;
    return Container();
      /*SingleChildScrollView(
      physics: BouncingScrollPhysics(),
      scrollDirection: Axis.horizontal,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 20, horizontal: 20),
        child: FittedBox(
          fit: BoxFit.fill,
          alignment: Alignment.topCenter,
          child: Row(
            children: <Widget>[
              FutureBuilder<Map<String, dynamic>>(
                  future: getBan,
              ),

              Container(
                width: 300,
                margin: EdgeInsets.only(right: 20),
                height: categoryHeight,
                decoration: BoxDecoration(
                    color: Colors.blue.shade400,
                    borderRadius: BorderRadius.all(Radius.circular(20.0)),
                    *//*image: DecorationImage(
                        fit: BoxFit.fill,
                        image: NetworkImage(
                          "http://appcompras.gestaoworks.com/app/images/bannerloja/3.jpg",
                        )
                    )*//*
                ),
                child: Padding(
                  padding: const EdgeInsets.all(12.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Container(
                        decoration: BoxDecoration(
                          //shape: BoxShape.circle,
                          *//*  image: DecorationImage(
                                fit: BoxFit.fill,
                                image: NetworkImage("http://appcompras.gestaoworks.com/app/images/bannerloja/3.jpg",)
                            )*//*
                        ),
                      ),

                    ],
                  ),
                ),
              ),
              Container(
                width: 300,
                margin: EdgeInsets.only(right: 20),
                height: categoryHeight,
                decoration: BoxDecoration(
                    color: Colors.blue.shade400,
                    borderRadius: BorderRadius.all(Radius.circular(20.0)),
                    *//*image: DecorationImage(
                        fit: BoxFit.fill,
                        image: NetworkImage("http://appcompras.gestaoworks.com/app/images/bannerloja/3.jpg",)
                    )*//*
                ),
                child: Container(
                  child: Padding(
                    padding: const EdgeInsets.all(12.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Container(
                          decoration: BoxDecoration(
                              //shape: BoxShape.circle,
                              *//*image: DecorationImage(
                                  fit: BoxFit.fill,
                                  image: NetworkImage("http://appcompras.gestaoworks.com/app/images/bannerloja/3.jpg",)
                              )*//*
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              Container(
                width: 300,
                margin: EdgeInsets.only(right: 20),
                height: categoryHeight,
                decoration: BoxDecoration(color: Colors.lightBlueAccent.shade400, borderRadius: BorderRadius.all(Radius.circular(20.0))),
                child: Padding(
                  padding: const EdgeInsets.all(12.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[

                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );*/
  }
}
