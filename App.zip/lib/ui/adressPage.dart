import 'package:apploja/class/Bairro.dart';
import 'package:apploja/ui/HomePage.dart';
import 'package:apploja/ui/loginPage.dart';
import 'package:apploja/ui/resetTelefonePage.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:apploja/style/theme.dart' as Theme;
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'dart:convert' show ascii, base64, json, jsonEncode;
import 'package:http/http.dart' as http;
import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';

final storage = FlutterSecureStorage();

class AddressPage extends StatefulWidget {
  AddressPage({this.codeCidade, this.jwt});
  final String codeCidade;
  final String jwt;

  @override
  _AddressPageState createState() => new _AddressPageState();
}

class _AddressPageState extends State<AddressPage>
    with SingleTickerProviderStateMixin {
  _AddressPageState();

  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  var maskFormatter = new MaskTextInputFormatter(mask: '######', filter: { "#": RegExp(r'[0-9]') });
  final FocusNode myFocusNodeRua = FocusNode();
  final FocusNode myFocusNodeNumber = FocusNode();
  final FocusNode myFocusNodeComplemento = FocusNode();

  TextEditingController ruaController = new TextEditingController();
  TextEditingController numeroController = new TextEditingController();
  TextEditingController complementoController = new TextEditingController();

  PageController _pageController;

  List<Bairro> _listBairros;
  String myBairro;

  Color left = Colors.black;
  Color right = Colors.white;

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      key: _scaffoldKey,
      body: NotificationListener<OverscrollIndicatorNotification>(
        onNotification: (overscroll) {
          overscroll.disallowGlow();
        },
        child: SingleChildScrollView(
          child: Container(
            width: MediaQuery.of(context).size.width,
            height: MediaQuery.of(context).size.height >= 775.0
                ? MediaQuery.of(context).size.height
                : 775.0,
            decoration: new BoxDecoration(
              gradient: new LinearGradient(
                  colors: [
                    Colors.white,
                    Colors.white30
                  ],
                  begin: const FractionalOffset(0.0, 0.0),
                  end: const FractionalOffset(1.0, 1.0),
                  stops: [0.0, 1.0],
                  tileMode: TileMode.clamp),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.max,
              children: <Widget>[
                Padding(
                  padding: EdgeInsets.only(top: 20.0),
                  //child: _buildMenuBar(context),
                ),
                Expanded(
                  flex: 2,
                  child: PageView(
                    controller: _pageController,
                    children: <Widget>[
                      new ConstrainedBox(
                        constraints: const BoxConstraints.expand(),
                        child: _buildSignIn(context),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _pageController?.dispose();
    super.dispose();
  }

  @override
  initState() {
    super.initState();
    this.postBairros(
        codeCidade: widget.codeCidade,
    );

    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);
    _pageController = PageController();
  }

  void showInSnackBar(String value) {
    FocusScope.of(context).requestFocus(new FocusNode());
    _scaffoldKey.currentState?.removeCurrentSnackBar();
    _scaffoldKey.currentState.showSnackBar(new SnackBar(
      content: new Text(
        value,
        textAlign: TextAlign.center,
        style: TextStyle(
            color: Colors.white,
            fontSize: 16.0,
            fontFamily: "WorkSansSemiBold"),
      ),
      backgroundColor: Colors.blue,
      duration: Duration(seconds: 3),
    ));
  }


  Future<bool> _onBackPressed(){
    return showDialog(
        context: context,
        builder: (context)=> new AlertDialog(
          title: new Text("Deseja voltar a tela anterior?"),
          actions: <Widget>[
            new FlatButton(
                onPressed: () => Navigator.of(context).pop(false),
                child: Text("Não")
            ),
            new FlatButton(
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (context)=> PageLogin())),
              child: new Text("Sim"),
            ),
          ],
        )
    );
  }

  Widget _buildSignIn(BuildContext context) {
    return WillPopScope(
      onWillPop: _onBackPressed,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.blue,
          title: Text("Cadastrar Endereço"),
          centerTitle: true,
        ),
        body: Container(
          padding: EdgeInsets.only(top: 23.0, left: 25.0, right: 25.0),
          child: Column(
            children: <Widget>[
              Stack(
                alignment: Alignment.center,
                overflow: Overflow.visible,
                children: <Widget>[
                  Card(
                    elevation: 2.0,
                    color: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8.0),
                    ),
                    child: Container(
                      width: 300.0,
                      height: 400.0,
                      child: Column(
                        children: <Widget>[
                          Padding(
                            padding: EdgeInsets.only(
                                top: 10.0, bottom: 10.0, left: 25.0, right: 25.0),
                            child: TextFormField(
                              //focusNode: myFocusNodeSenhaReset,
                              keyboardType: TextInputType.phone,
                              style: TextStyle(
                                  fontFamily: "WorkSansSemiBold",
                                  fontSize: 16.0,
                                  color: Colors.black),
                              decoration: InputDecoration(
                                border: InputBorder.none,
                                icon: Icon(
                                  Icons.location_on,
                                  color: Colors.black,
                                  size: 22.0,
                                ),
                                hintText: "Cidade",
                                hintStyle: TextStyle(fontFamily: "WorkSansSemiBold", fontSize: 17.0),
                              ),
                            ),
                          ),
                          Container(
                            width: 250.0,
                            height: 1.0,
                            color: Colors.grey[400],
                          ),
                          Padding(
                              padding: EdgeInsets.only(
                                  top: 10.0, bottom: 10.0, left: 25.0, right: 25.0),
                              child: Row(
                                children: <Widget>[

                                  Padding(
                                    padding: EdgeInsets.only(
                                        top: 10.0, bottom: 10.0, left: 0, right: 18.0),
                                    child: Icon(Icons.my_location),
                                  ),
                                  DropdownButton(
                                    icon: Icon(
                                      Icons.arrow_drop_down,
                                    ),
                                    iconSize: 20,
                                    hint: Text("Bairro"),
                                    style: TextStyle(
                                      fontFamily: "WorkSansSemiBold",
                                      fontSize: 16.0,
                                      color: Colors.black,
                                    ),
                                    items: _listBairros?.map((item){
                                      return new DropdownMenuItem(
                                        child: new Text(item.nome),
                                        value: item.id,
                                      );
                                    })?.toList() ?? [],
                                    onChanged: (value) {
                                      setState(() {
                                        myBairro = value;
                                      });
                                    },
                                    value: myBairro,
                                  ),
                                ],
                              )
                          ),
                          Container(
                            width: 250.0,
                            height: 1.0,
                            color: Colors.grey[400],
                          ),
                          Padding(
                            padding: EdgeInsets.only(
                                top: 10.0, bottom: 10.0, left: 25.0, right: 25.0),
                            child: TextFormField(
                              focusNode: myFocusNodeRua,
                              //validator: (context){},
                              controller: ruaController,
                              keyboardType: TextInputType.text,
                              style: TextStyle(
                                  fontFamily: "WorkSansSemiBold",
                                  fontSize: 16.0,
                                  color: Colors.black),
                              decoration: InputDecoration(
                                labelText: "Rua",
                                border: InputBorder.none,
                                icon: Icon(
                                  Icons.local_post_office,
                                  color: Colors.black,
                                  size: 22.0,
                                ),
                                hintText: "Rua",
                                hintStyle: TextStyle(fontFamily: "WorkSansSemiBold", fontSize: 17.0),
                              ),
                            ),
                          ),
                          Container(
                            width: 250.0,
                            height: 1.0,
                            color: Colors.grey[400],
                          ),
                          Padding(
                            padding: EdgeInsets.only(
                                top: 10.0, bottom: 10.0, left: 25.0, right: 25.0),
                            child: TextFormField(
                              focusNode: myFocusNodeNumber,
                              //validator: (context){},
                              controller: numeroController,
                              keyboardType: TextInputType.number,
                              inputFormatters: [maskFormatter],
                              style: TextStyle(
                                  fontFamily: "WorkSansSemiBold",
                                  fontSize: 16.0,
                                  color: Colors.black),
                              decoration: InputDecoration(
                                labelText: "Número",
                                border: InputBorder.none,
                                icon: Icon(
                                  Icons.location_city,
                                  color: Colors.black,
                                  size: 22.0,
                                ),
                                hintText: "Número",
                                hintStyle: TextStyle(fontFamily: "WorkSansSemiBold", fontSize: 17.0),
                              ),
                            ),
                          ),
                          Container(
                            width: 250.0,
                            height: 1.0,
                            color: Colors.grey[400],
                          ),
                          Padding(
                            padding: EdgeInsets.only(
                                top: 10.0, bottom: 10.0, left: 25.0, right: 25.0),
                            child: TextFormField(
                              focusNode: myFocusNodeComplemento,
                              //validator: (context){},
                              controller: complementoController,
                              keyboardType: TextInputType.text,
                              style: TextStyle(
                                  fontFamily: "WorkSansSemiBold",
                                  fontSize: 16.0,
                                  color: Colors.black),
                              decoration: InputDecoration(
                                labelText: "Complemento",
                                border: InputBorder.none,
                                icon: Icon(
                                  Icons.add,
                                  color: Colors.black,
                                  size: 22.0,
                                ),
                                hintText: "Comlemento",
                                hintStyle: TextStyle(fontFamily: "WorkSansSemiBold", fontSize: 17.0),
                              ),
                            ),
                          ),
                          Container(
                            width: 250.0,
                            height: 1.0,
                            color: Colors.grey[400],
                          ),
                        ],
                      ),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.only(top: 400.0),
                    decoration: new BoxDecoration(
                      borderRadius: BorderRadius.all(Radius.circular(5.0)),
                      boxShadow: <BoxShadow>[
                        BoxShadow(
                          color: Colors.white30,
                          offset: Offset(1.0, 6.0),
                          blurRadius: 20.0,
                        ),
                        BoxShadow(
                          color: Colors.blueAccent,
                          offset: Offset(1.0, 6.0),
                          blurRadius: 20.0,
                        ),
                      ],
                      gradient: new LinearGradient(
                          colors: [
                            Colors.blue,
                            Colors.blueAccent
                          ],
                          begin: const FractionalOffset(0.2, 0.2),
                          end: const FractionalOffset(1.0, 1.0),
                          stops: [0.0, 1.0],
                          tileMode: TileMode.clamp),
                    ),
                    child: MaterialButton(
                        highlightColor: Colors.transparent,
                        splashColor: Theme.Colors.loginGradientEnd,
                        //shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(5.0))),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(
                              vertical: 10.0, horizontal: 42.0),
                          child: Text(
                            "Confirmar",
                            style: TextStyle(
                                color: Colors.white,
                                fontSize: 20.0,
                                fontFamily: "WorkSansBold"),
                          ),
                        ),

                        onPressed: () async {
                          var jwt = await postAddress(
                            rua: ruaController.text,
                            numero: numeroController.text,
                            complemento: complementoController.text,
                            codeBairro: myBairro,
                            codeCidade: widget.codeCidade,
                            jwt: widget.jwt
                          );
                          if(jwt["status"] == "success"){
                            displayDialog(context, "", "Endereço cadastrado com sucesso");
                            Navigator.push(context, MaterialPageRoute(builder: (context) => HomePage()));

                          } else{
                            String aviso = jwt["data"]["mensagem"];
                            displayDialog(context, "ENVIADO!", aviso);
                          }
                        }
                    ),
                  ),
                ],
              ),

            ],
          ),
        ),
      ),
    );
  }



  Future<Map> postAddress({
    @required String rua,
    @required String numero,
    @required String complemento,
    @required String codeCidade,
    @required String codeBairro,
    @required String jwt }) async{
    try {
      final response = await http.post(
          'http://appcompras.gestaoworks.com/rest.php',
          headers: {
            'Content-Type': 'application/json; charset=UTF-8',
            'authorization': 'Bearer '+ jwt,
          },
          body: jsonEncode(<String, String>{
            "class": "ServiceEndereco",
            "method": "GravarEndereco",
            "rua": rua,
            "numero": numero,
            "complemento": complemento,
            "cidade": codeCidade,
            "bairro": codeBairro
          })
      );
      Map<dynamic, dynamic> newAddress = json.decode(response.body);
      return newAddress;
    } on Exception catch(_){
      Map<String, String> status = {"mensagem": "Não foi possivel conectar a internet. Tente novamente mais tarde!"};
      return status;
    }
  }

  Future<List<Bairro>> postBairros({@required String codeCidade}) async{
    print("Entrouuu");
    final response = await http.post(
      'http://appcompras.gestaoworks.com/rest.php',
      headers: {
        'Content-Type': 'application/json; charset=UTF-8',
        'authorization': 'Basic qtDwW3MktkK0Oi8GtfSSGzBsrfcKayBH'
      },
      body: jsonEncode(<String, String>{
        "class": "ServiceBairro",
        "method": "ListaBairros",
        "cidade": codeCidade
      })
    );
    Map<String, dynamic> bairros = json.decode(response.body);
    List<dynamic> listBairros = bairros["data"];
    List<Bairro> listaBairroLocal = [];

    listBairros.forEach((element) {
      Bairro bairro = new Bairro(element["id"], element["nome"]);
      listaBairroLocal.add(bairro);
    });

    setState(() {
      _listBairros = listaBairroLocal;
    });
   return listaBairroLocal;
  }

  void displayDialog(context, title, text) => showDialog(
    context: context,
    builder: (context) =>
        AlertDialog(
            title: Text(title),
            content: Text(text),
            actions: <Widget>[
              new FlatButton(
                  onPressed: () =>Navigator.push(context, MaterialPageRoute(builder: (context) => ResetTelefonePage())),
                  child: Text("OK")
              ),
            ]
        ),
  );

}
