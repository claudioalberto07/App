import 'package:flutter/material.dart';

class MenuInfoLoja extends StatefulWidget{
  MenuInfoLoja(this.mapInfoLoja);
  final Map<String, dynamic> mapInfoLoja;
  @override
  _MenuInfoLojaState createState() => new _MenuInfoLojaState();
}

class _MenuInfoLojaState extends State<MenuInfoLoja>{
  int itemSelect = 0;

  Widget _listInfoLoja() {
    return ListView(
      children: <Widget>[
        _avatar(),
        _itemInfoLoja(widget.mapInfoLoja["endereco1"], Icons.location_city, 1, () {}),
        _itemInfoLoja(widget.mapInfoLoja["endereco2"], Icons.location_city, 2, () {}),
        _itemInfoLoja(widget.mapInfoLoja["telefone"], Icons.call, 3, () {}),

      ],
    );
  }
  Widget _itemInfoLoja(String text, IconData icon, int item, Function onTap) {
    return ListTile(
      leading: Icon(icon),
      onTap: onTap,
      selected: item == itemSelect,
      title: Text(
        text,
        style: TextStyle(fontWeight: FontWeight.bold),
      ),
    );
  }
  Widget _avatar() {
    return Padding(
      padding: EdgeInsets.all(18.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: <Widget>[
          CircleAvatar(
            backgroundImage: NetworkImage(
              "http://appcompras.gestaoworks.com/" + widget.mapInfoLoja["imagem"]
            ),
            child: Text(''),
            radius: 50.0,
          ),
          Divider(),
          Text( widget.mapInfoLoja["nome"],
            style: TextStyle(fontWeight: FontWeight.bold
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Material(
      child: Container(
        width: double.infinity,
        height: double.infinity,
        color: Colors.white,
        child: _listInfoLoja(),
      ),
    );
  }

}

