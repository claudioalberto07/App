import 'package:apploja/API.dart';
import 'package:apploja/class/Endereco.dart';
import 'package:apploja/componentes/CustomAppBarItem.dart';
import 'package:apploja/ui/MenuLateral.dart';
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:http/http.dart' as http;

import 'dart:convert';

class MeusEnderecosPage extends StatefulWidget {

  MeusEnderecosPage({this.jwt, this.onTapMenu, this.mapJwt});
  final String jwt;
  final Map mapJwt;
  final Function onTapMenu;

  @override
  _MeusEnderecosPageState createState() => _MeusEnderecosPageState();

}

class _MeusEnderecosPageState extends State<MeusEnderecosPage> {

  int _selectIndex = 0;

  void _selectTab(int index){
    setState(() {
      _selectIndex = index;
    });
  }
  TextEditingController buscarController = TextEditingController();
  final FocusNode myFocusNodeBuscar = FocusNode();
  ScrollController controller = ScrollController();
  bool closeTopContainer = false;
  double topContainer = 0;

  Future<List<Endereco>>  _fetchMeusEnderecos() async{
    try{
      final response = await http.post(
        API.url + "?class=ServiceEndereco&method=ListaEnderecoDisponiveis",
        headers: {
          'authorization': 'Bearer ${widget.jwt}',
          'Accept': 'application/json',
          'Content-Type': 'application/json; charset=UTF-8',
        },
      );
      if(response.statusCode == 200){
        List jsonResponse = json.decode(response.body)["data"];
        print(jsonResponse);
        return jsonResponse.map((endereco) => new Endereco.fromJson(endereco)).toList();
      }
    } on Exception catch(_){

    }

  }

  @override
  void initState() {
    super.initState();

    controller.addListener(() {
      double value = controller.offset/119;
      setState(() {
        topContainer = value;
        closeTopContainer = controller.offset > 50;
      });
    });
  }

  ListView _enderecoListView(List<Endereco> data){
    return ListView.builder(
      scrollDirection: Axis.vertical,
        shrinkWrap: true,
        itemCount: data.length,
        itemBuilder: (context, index){
          return Card(
            elevation: 2.0,
            color: Colors.white,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(8.0),
            ),
            child: Column(
              children: <Widget>[
                Container(
                  width: 320.0,
                  height: 50.0,
                  child: Column(
                    children: <Widget>[
                      Text(data[index].rua),
                      Text(data[index].numero),
                      Text(data[index].complemento),
                    ],
                  ),
                ),
              ],
            ),

          );
        }
    );
  }

  @override
  Widget build(BuildContext context) {
    final Size size = MediaQuery.of(context).size;
    final double categoryHeight = size.height*0.30;
    final double categoryHeight2 = MediaQuery.of(context).size.height * 0.30 - 50;


    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.white,
        drawer: Drawer(
            child: MenuLateral(widget.jwt)
        ),
        appBar: AppBar(
          elevation: 0,
          backgroundColor: Colors.blue,
          actions: <Widget>[
            IconButton(
              icon: Icon(
                  Icons.location_on,
                  color: Colors.white
              ),
              onPressed: () {},
            )
          ],
        ),
        bottomNavigationBar: CustomBottomAppBar(
          onTabSelected: _selectTab,
          items: [
            CustomAppBarItem(icon: Icons.list),
            CustomAppBarItem(icon: Icons.home),
            CustomAppBarItem(icon: Icons.person),
          ],
        ),
        body: Container(
          padding: EdgeInsets.all(20.0),
          height: 300.0,
          child: Column(
            children: <Widget>[
              const SizedBox(
                height: 10,
              ),

              FutureBuilder<List<Endereco>>(
                future: _fetchMeusEnderecos(),
                builder: (context, snapshot){
                  switch (snapshot.connectionState) {
                    case ConnectionState.none:
                      return Center(child: CircularProgressIndicator());
                    case ConnectionState.waiting:
                      return Center(child: CircularProgressIndicator());
                    default:
                      if (snapshot.hasError)
                        return Center(child: CircularProgressIndicator());
                      else
                        List<Endereco> data = snapshot.data;
                        return _enderecoListView(snapshot.data);
                  }
                },
              ),

            ],
          ),
        ),
      ),
    );
  }
}

