import 'package:apploja/ui/HomePage.dart';
import 'package:apploja/ui/PerfilPage.dart';
import 'package:apploja/ui/meusEnderecosPage.dart';
import 'package:flutter/material.dart';
import 'dart:convert';
import 'loginPage.dart';

class MenuLateral extends StatefulWidget{
  MenuLateral(this.jwt);
  final String jwt;
  @override
  _MenuLateralState createState() => new _MenuLateralState();
}

class _MenuLateralState extends State<MenuLateral>{
  int itemSelect = 0;

  void _menuInicio(BuildContext context){
     Navigator.pop(context);
     Navigator.push(context, MaterialPageRoute(builder: (context) => HomePage(jwt: widget.jwt)));
}
  void _menuPerfil(BuildContext context){
    var jwt = widget.jwt.split(".");
    Map _mapPerfil = json.decode(ascii.decode(base64.decode(base64.normalize(jwt[1]))));
    print(_mapPerfil);
    Navigator.pop(context);
    Navigator.push(context, MaterialPageRoute(builder: (context) => PerfilPage(jwt:widget.jwt, mapJwt: _mapPerfil)));
  }
  void _menuEndereco(BuildContext context){
    Navigator.pop(context);
    Navigator.push(context, MaterialPageRoute(builder: (context) => MeusEnderecosPage(jwt:widget.jwt)));
  }
  void _menuSair(BuildContext context){
    Navigator.pushAndRemoveUntil(
        context,
        PageRouteBuilder(pageBuilder: (BuildContext context, Animation animation,
            Animation secondaryAnimation) {
          return PageLogin();
        }, transitionsBuilder: (BuildContext context, Animation<double> animation,
            Animation<double> secondaryAnimation, Widget child) {
          return new SlideTransition(
            position: new Tween<Offset>(
              begin: const Offset(1.0, 0.0),
              end: Offset.zero,
            ).animate(animation),
            child: child,
          );
        }),
            (Route route) => false);
  }

  Widget _listMenu() {
    return ListView(
      children: <Widget>[
        _avatar(),
        _itemMenu("Início", Icons.home, 0, (){_menuInicio(context);}),
        _itemMenu("Perfil", Icons.person_outline, 1, () {_menuPerfil(context);}),
        _itemMenu("Meus Endereços", Icons.location_city, 1, () {_menuEndereco(context);}),
        _itemMenu("Meus Pedidos", Icons.shopping_cart, 2, (){_menuInicio(context);}),
        Divider(),
        _itemMenu("Sair", Icons.keyboard_return, 3, () {_menuSair(context);}),
      ],
    );
  }
  Widget _itemMenu(String text, IconData icon, int item, Function onTap) {
    return ListTile(
        leading: Icon(icon),
        onTap: onTap,
        selected: item == itemSelect,
        title: Text(
          text,
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
      );
  }
  Widget _avatar() {
    return Padding(
      padding: EdgeInsets.all(18.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          CircleAvatar(
            backgroundColor: Colors.brown.shade800,
            child: Text(''),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Material(
      child: Container(
        width: double.infinity,
        height: double.infinity,
        color: Colors.white,
        child: _listMenu(),
      ),
    );
  }
  
}

