import 'package:apploja/componentes/CustomAppBarItem.dart';
import 'package:apploja/ui/MenuLateral.dart';
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'dart:convert';

class PerfilPage extends StatefulWidget {

  PerfilPage({this.jwt, this.onTapMenu, this.mapJwt});
  final String jwt;
  final Map mapJwt;
  final Function onTapMenu;

  @override
  _PerfilPageState createState() => _PerfilPageState();
}

class _PerfilPageState extends State<PerfilPage> {

  int _selectIndex = 0;
  Map<String, dynamic> _mapPerfil = {};

  void _selectTab(int index){
    setState(() {
      _selectIndex = index;
    });
  }
  TextEditingController buscarController = TextEditingController();
  final FocusNode myFocusNodeBuscar = FocusNode();
  final CategoriesScroller categoriesScroller = CategoriesScroller();
  ScrollController controller = ScrollController();
  bool closeTopContainer = false;
  double topContainer = 0;


  @override
  void initState() {
    super.initState();
    controller.addListener(() {
      double value = controller.offset/119;
      setState(() {
        topContainer = value;
        closeTopContainer = controller.offset > 50;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    final Size size = MediaQuery.of(context).size;
    final double categoryHeight = size.height*0.30;
    final double categoryHeight2 = MediaQuery.of(context).size.height * 0.30 - 50;

    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.white,
        drawer: Drawer(
            child: MenuLateral(widget.jwt)
        ),
        appBar: AppBar(
          elevation: 0,
          backgroundColor: Colors.blue,
          actions: <Widget>[
            IconButton(
              icon: Icon(
                  Icons.location_on,
                  color: Colors.white
              ),
              onPressed: () {},
            )
          ],
        ),
        bottomNavigationBar: CustomBottomAppBar(
          onTabSelected: _selectTab,
          items: [
            CustomAppBarItem(icon: Icons.list),
            CustomAppBarItem(icon: Icons.home),
            CustomAppBarItem(icon: Icons.person),
          ],
        ),
        body: Container(
          padding: EdgeInsets.all(20.0),
          height: 300.0,
          child: Column(
            children: <Widget>[
              const SizedBox(
                height: 10,
              ),
              Card(
                elevation: 2.0,
                color: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8.0),
                ),
                child: Column(
                  children: <Widget>[
                    CircleAvatar(
                      backgroundImage: AssetImage("imagens/pessoa.png"),
                      backgroundColor: Colors.brown,
                      child: Text(''),
                      radius: 50.0,
                    ),
                    Text(widget.mapJwt["username"]),
                    Text(widget.mapJwt["userphone"]),

                    Container(
                      width: 320.0,
                      height: 50.0,
                      child: Column(
                        children: <Widget>[
                        ],
                      ),
                    ),
                  ],
                ),

              ),
            ],
          ),
        ),
      ),
    );
  }
}

class CategoriesScroller extends StatelessWidget {
  const CategoriesScroller();
  @override
  Widget build(BuildContext context) {
    final double categoryHeight = MediaQuery.of(context).size.height * 0.30 - 50;
    return Container();
  }
}
