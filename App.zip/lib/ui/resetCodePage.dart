import 'file:///C:/Users/SESI/AndroidStudioProjects/app_loja/lib/ui/HomePage.dart';
import 'package:apploja/ui/loginPage.dart';
import 'package:apploja/ui/resetSenhaPage.dart';
import 'package:apploja/ui/resetTelefonePage.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:apploja/style/theme.dart' as Theme;
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'dart:convert' show ascii, base64, json, jsonEncode;
import 'package:http/http.dart' as http;
import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';

final storage = FlutterSecureStorage();

class ResetCodePage extends StatefulWidget {
  final String telefone;
  ResetCodePage({@required this.telefone, String});
  @override
  _ResetCodePageState createState() => new _ResetCodePageState(this.telefone);
}

class _ResetCodePageState extends State<ResetCodePage>
    with SingleTickerProviderStateMixin {
  _ResetCodePageState(String telefone);
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  var maskFormatter = new MaskTextInputFormatter(
      mask: '####',
      filter: { "#": RegExp(r'[0-9]') });
  final FocusNode myFocusNodeTelefoneReset = FocusNode();
  final FocusNode myFocusNodeCodeReset = FocusNode();

  TextEditingController resetTelefoneController = new TextEditingController();
  TextEditingController resetCodeController = new TextEditingController();

  PageController _pageController;


  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      key: _scaffoldKey,
      body: NotificationListener<OverscrollIndicatorNotification>(
        onNotification: (overscroll) {
          overscroll.disallowGlow();
        },
        child: SingleChildScrollView(
          child: Container(
            width: MediaQuery.of(context).size.width,
            height: MediaQuery.of(context).size.height >= 775.0
                ? MediaQuery.of(context).size.height
                : 775.0,
            decoration: new BoxDecoration(
              gradient: new LinearGradient(
                  colors: [
                    Colors.white,
                    Colors.white30
                  ],
                  begin: const FractionalOffset(0.0, 0.0),
                  end: const FractionalOffset(1.0, 1.0),
                  stops: [0.0, 1.0],
                  tileMode: TileMode.clamp),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.max,
              children: <Widget>[
                Padding(
                  padding: EdgeInsets.only(top: 20.0),
                  //child: _buildMenuBar(context),
                ),
                Expanded(
                  flex: 2,
                  child: PageView(
                    controller: _pageController,
                    children: <Widget>[
                      new ConstrainedBox(
                        constraints: const BoxConstraints.expand(),
                        child: _buildSignIn(context),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _pageController?.dispose();
    super.dispose();
  }

  @override
  initState() {
    super.initState();

    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);
    _pageController = PageController();
  }

  void showInSnackBar(String value) {
    FocusScope.of(context).requestFocus(new FocusNode());
    _scaffoldKey.currentState?.removeCurrentSnackBar();
    _scaffoldKey.currentState.showSnackBar(new SnackBar(
      content: new Text(
        value,
        textAlign: TextAlign.center,
        style: TextStyle(
            color: Colors.white,
            fontSize: 16.0,
            fontFamily: "WorkSansSemiBold"),
      ),
      backgroundColor: Colors.blue,
      duration: Duration(seconds: 3),
    ));
  }


  Future<bool> _onBackPressed(){
    return showDialog(
        context: context,
        builder: (context)=> new AlertDialog(
          title: new Text("Deseja voltar a tela anterior?"),
          //content: new Text("Você voltará a tela anterior"),
          actions: <Widget>[
            new FlatButton(
                onPressed: () => Navigator.of(context).pop(false),
                child: Text("Não")
            ),
            new FlatButton(
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (context)=> ResetTelefonePage())),
              child: new Text("Sim"),
            ),
          ],
        )
    );
  }

  Widget _buildSignIn(BuildContext context) {
    return WillPopScope(
      onWillPop: _onBackPressed,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.blue,
          title: Text("Redefinir a senha"),
          centerTitle: true,
        ),
        body: Container(
          padding: EdgeInsets.only(top: 23.0, left: 25.0, right: 25.0),
          child: Column(
            children: <Widget>[
              Stack(
                alignment: Alignment.center,
                overflow: Overflow.visible,
                children: <Widget>[
                  Card(
                    elevation: 2.0,
                    color: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8.0),
                    ),
                    child: Container(
                      width: 300.0,
                      height: 300.0,
                      child: Column(
                        children: <Widget>[
                          Padding(
                            padding: EdgeInsets.only(
                                top: 20.0, bottom: 20.0, left: 25.0, right: 25.0),
                            child: TextFormField(
                              focusNode: myFocusNodeTelefoneReset,
                              //validator: (context){},
                              controller: resetTelefoneController,
                              keyboardType: TextInputType.phone,
                              inputFormatters: [maskFormatter],
                              style: TextStyle(
                                  fontFamily: "WorkSansSemiBold",
                                  fontSize: 16.0,
                                  color: Colors.black),
                              decoration: InputDecoration(
                                labelText: "(83) 9 99327-0664",
                                border: InputBorder.none,
                                icon: Icon(
                                  Icons.phone,
                                  color: Colors.black,
                                  size: 22.0,
                                ),
                                hintText: "Telefone",
                                hintStyle: TextStyle(fontFamily: "WorkSansSemiBold", fontSize: 17.0),
                              ),
                            ),
                          ),
                          Container(
                            width: 250.0,
                            height: 1.0,
                            color: Colors.grey[400],
                          ),
                          Padding(
                            padding: EdgeInsets.only(
                                top: 20.0, bottom: 20.0, left: 25.0, right: 25.0),
                            child: TextFormField(
                              focusNode: myFocusNodeCodeReset,
                              //validator: (context){},
                              controller: resetCodeController,
                              keyboardType: TextInputType.phone,
                              inputFormatters: [maskFormatter],
                              style: TextStyle(
                                  fontFamily: "WorkSansSemiBold",
                                  fontSize: 16.0,
                                  color: Colors.black),
                              decoration: InputDecoration(
                                border: InputBorder.none,
                                icon: Icon(
                                  Icons.security,
                                  color: Colors.black,
                                  size: 22.0,
                                ),
                                hintText: "Código",
                                hintStyle: TextStyle(fontFamily: "WorkSansSemiBold", fontSize: 17.0),
                              ),
                            ),
                          ),
                          Container(
                            width: 250.0,
                            height: 1.0,
                            color: Colors.grey[400],
                          ),
                        ],
                      ),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.only(top: 170.0),
                    decoration: new BoxDecoration(
                      borderRadius: BorderRadius.all(Radius.circular(5.0)),
                      boxShadow: <BoxShadow>[
                        BoxShadow(
                          color: Colors.white30,
                          offset: Offset(1.0, 6.0),
                          blurRadius: 20.0,
                        ),
                        BoxShadow(
                          color: Colors.blueAccent,
                          offset: Offset(1.0, 6.0),
                          blurRadius: 20.0,
                        ),
                      ],
                      gradient: new LinearGradient(
                          colors: [
                            Colors.blue,
                            Colors.blueAccent
                          ],
                          begin: const FractionalOffset(0.2, 0.2),
                          end: const FractionalOffset(1.0, 1.0),
                          stops: [0.0, 1.0],
                          tileMode: TileMode.clamp),
                    ),
                    child: MaterialButton(
                        highlightColor: Colors.transparent,
                        splashColor: Theme.Colors.loginGradientEnd,
                        //shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(5.0))),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(
                              vertical: 10.0, horizontal: 42.0),
                          child: Text(
                            "Enviar",
                            style: TextStyle(
                                color: Colors.white,
                                fontSize: 20.0,
                                fontFamily: "WorkSansBold"),
                          ),
                        ),

                        onPressed: () async {
                          var jwt = await postTelefone(
                              telefone: resetTelefoneController.text);
                          if(jwt["status"] != "error"){
                            String aviso = jwt["data"]["mensagem"];
                            displayDialog(context, "", aviso);
                          } else{
                            String aviso = jwt["data"]["mensagem"];
                            displayDialog(context, "ENVIADO!", aviso);
                          }
                        }
                    ),
                  ),
                ],
              ),

            ],
          ),
        ),
      ),
    );
  }


  Future<Map> postTelefone({@required String telefone}) async{
    final response = await http.post(
        'http://appcompras.gestaoworks.com/rest.php',
        headers: {
          'Content-Type': 'application/json; charset=UTF-8',
          'authorization': 'Basic qtDwW3MktkK0Oi8GtfSSGzBsrfcKayBH',
          'Accept': 'application/json',
        },
        body: jsonEncode( <String, String>{
          "class": "ServiceUsuario",
          "method": "GerarTokenSMS",
          "telefone" : telefone
        })
    );
    Map<dynamic, dynamic> user = json.decode(response.body);
    return user;
  }
  Future<Map> postSignin({@required String senha,
    @required String nome,
    @required String telefone,
    @required String cidade}) async{
    final response = await http.post(
        'http://appcompras.gestaoworks.com/rest.php',
        headers: {
          'Content-Type': 'application/json; charset=UTF-8',
          'authorization': 'Basic qtDwW3MktkK0Oi8GtfSSGzBsrfcKayBH',
          'Accept': 'application/json',
        },
        body: jsonEncode( <String, String>{
          "class": "ServiceUsuario",
          "method": "GravarUsuario",
          "senha": senha,
          "telefone" : telefone,
          "nome" : nome,
          "cidade" : cidade
        })
    );
    Map<dynamic, dynamic> user = json.decode(response.body);
    return user;
  }

  Future<dynamic> getCity() async{
    final response = await http.get(
      'http://appcompras.gestaoworks.com/rest.php?class=ServiceCidade&method=ListaCidades',
      headers: {
        'Content-Type': 'application/json; charset=UTF-8',
        'authorization': 'Basic qtDwW3MktkK0Oi8GtfSSGzBsrfcKayBH'
      },
    );
    Map<String, dynamic> cidades = json.decode(response.body);
    List<dynamic> listCidade = cidades["data"];

    listCidade.forEach((element) {
      print(element["id"]);
    });

    if(cidades["status"] == "sucess")
      return listCidade;
    else
      return false;
  }

  void displayDialog(context, title, text) => showDialog(
    context: context,
    builder: (context) =>
        AlertDialog(
            title: Text(title),
            content: Text(text),
            actions: <Widget>[
              new FlatButton(
                  onPressed: () =>Navigator.push(context, MaterialPageRoute(builder: (context) => ResetSenhaPage())),
                  child: Text("OK")
              ),
            ]
        ),
  );

}
