import 'dart:convert';
import 'package:apploja/componentes/CustomAppBarItem.dart';
import 'package:apploja/API.dart';
import 'package:apploja/class/Produto.dart';
import 'package:apploja/componentes/custom_number_pick.dart';
import 'package:apploja/ui/MenuInfoLoja.dart';
import 'package:apploja/ui/MenuLateral.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/cupertino.dart';
import 'package:http/http.dart' as http;

class LojaPage extends StatefulWidget {

  LojaPage({this.jwt, this.idLoja });
  final String jwt;
  final String idLoja;
  var payload;

  @override
  _LojaPageState createState() => _LojaPageState();

}

class _LojaPageState extends State<LojaPage> {
  int _selectIndex = 0;

  void _selectTab(int index){
    setState(() {
      _selectIndex = index;
    });
  }
  TextEditingController buscarController = TextEditingController();
  final FocusNode myFocusNodeBuscar = FocusNode();
  ScrollController controller = ScrollController();
  bool closeTopContainer = false;
  double topContainer = 0;

  List<Widget> listCardLojas = [];
  Map<String, dynamic> _mapInfoLoja = {};
  List<dynamic> _listProdutos = [];


  Future<List<Produto>> _fetchProdutos() async {
    try {
      final response = await http.post(
        API.url + '?class=ServiceProduto&method=ListaInfoLojaProdutosDisponiveis&loja=${widget.idLoja}',
        headers: {
          'authorization': 'Bearer ${widget.jwt}',
          'Accept': 'application/json',
          'Content-Type': 'application/json; charset=UTF-8',
        },
      );
      if (response.statusCode == 200) {
        List retorno = json.decode(response.body)["data"]["produtos"];
        return retorno.map((produto) => new Produto.fromJson(produto)).toList();
      }
    } on Exception catch(_){
    }
  }


  Future<Map<dynamic, dynamic>> _fetchInfoLoja() async {
    try {
      final response = await http.post(
        API.url + '?class=ServiceProduto&method=ListaInfoLojaProdutosDisponiveis&loja=${widget.idLoja}',
        headers: {
          'authorization': 'Bearer ${widget.jwt}',
          'Accept': 'application/json',
          'Content-Type': 'application/json; charset=UTF-8',
        },
      );
      if (response.statusCode == 200) {
        Map<String, dynamic> retorno = json.decode(response.body)["data"];
        setState(() {
          _mapInfoLoja = retorno["infoloja"];
        });
        return retorno["infoloja"];
      }
    } on Exception catch(_){
    }
  }

  Future<Widget> buildInfoCard(Map mapInfoLoja) async {
    return Container(
      height: 120.0,
      margin: const EdgeInsets.symmetric(vertical: 5.0, horizontal: 20.0),
      child: new Stack(
        children: <Widget>[
          Container(
            height: 124.0,
            alignment: FractionalOffset.centerLeft,
            decoration: new BoxDecoration(
              color: Colors.black12,
              shape: BoxShape.rectangle,
              borderRadius: new BorderRadius.circular(8.0),
              boxShadow: <BoxShadow>[
                new BoxShadow(
                  color: Color(0x023047),
                  blurRadius: 10.0,
                  offset: new Offset(0.0, 10.0),
                ),
              ],
            ),
            child: Row(
              children: <Widget>[
                Column(
                  children: <Widget>[
                    Container(
                      padding: EdgeInsets.only(left: 10, top: 10, bottom: 10),
                      child: CircleAvatar(
                        backgroundImage: NetworkImage(
                            API.pathImage + mapInfoLoja["imagem"] == null ?
                            'imagens/google.png':  API.pathImage + mapInfoLoja["imagem"] ),
                        backgroundColor: Colors.brown,
                        child: Text(''),
                        radius: 50.0,
                      ),
                    ),
                  ],
                ),
                Divider(),
                Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    Padding(
                      padding: EdgeInsets.only(left: 2, top: 10, bottom: 2, ),
                      child:Text(
                        mapInfoLoja["nome"],
                        style: TextStyle(
                            fontFamily: "WorkSansSemiBold",
                            fontSize: 16.0,
                            color: Colors.black
                        ),
                      ),
                    ),
                    Padding(
                        padding: EdgeInsets.only(left: 0, top: 2, bottom: 2),
                        child: Row(
                          children: <Widget>[
                            Icon(Icons.local_shipping, size: 15),
                            Padding(padding: EdgeInsets.symmetric(horizontal: 2)),
                            Text(mapInfoLoja["entrega"] == "C" ? mapInfoLoja["informacoesentrega"]: "Entrega Grátis",
                              style: TextStyle(
                                fontSize: 15
                              ),),
                          ],
                        )
                    ),
                    Padding(
                        padding: EdgeInsets.only(left: 0, top: 2, bottom: 2),
                        child: Row(
                          children: <Widget>[
                            Text(mapInfoLoja["mensagemfuncionamento"]),
                          ],
                        )
                    ),
                  ],
                ),
                Column(
                  children: <Widget>[
                    Container(
                      padding: EdgeInsets.only(left: 2, top: 2, bottom: 2),
                      child: CircleAvatar(
                        backgroundImage: AssetImage(
                            mapInfoLoja["aberta"] == "s" ? 'imagens/open.png':  'imagens/open.png'),
                        backgroundColor: Colors.brown,
                        child: Text(''),
                        radius: 10.0,
                      ),
                    ),
                  ],
                )
              ],
            )
          ),
        ],
      ),
    );
  }

  @override
  void initState() {
    super.initState();
    _fetchInfoLoja();

    controller.addListener(() {
      double value = controller.offset/119;
      setState(() {
        topContainer = value;
        closeTopContainer = controller.offset > 50;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    final Size size = MediaQuery.of(context).size;
    final double categoryHeight = size.height*0.30;

    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.white,
        drawer: Drawer(child: MenuLateral(widget.jwt)),
        endDrawer: Drawer(child: MenuInfoLoja(_mapInfoLoja),),
        appBar: AppBar(
          elevation: 0,
          backgroundColor: Colors.blue,
          actions: <Widget>[
          ],
        ),
        bottomNavigationBar: CustomBottomAppBar(
          onTabSelected: _selectTab,
          items: [
            CustomAppBarItem(icon: Icons.location_on),
            CustomAppBarItem(icon: Icons.home),
            CustomAppBarItem(icon: Icons.shopping_cart),
          ],
        ),
        body: Container(
          height: size.height,
          child: Column(
            children: <Widget>[
              const SizedBox(
                height: 10,
              ),
              AnimatedOpacity(
                duration: const Duration(milliseconds: 200),
                opacity: closeTopContainer?0:1,
                child: AnimatedContainer(
                    duration: const Duration(milliseconds: 100),
                    width: size.width,
                    alignment: Alignment.topCenter,
                    height: closeTopContainer?0:categoryHeight,

                    child: FutureBuilder<Widget>(
                      future: buildInfoCard(_mapInfoLoja),
                      builder: (BuildContext context, AsyncSnapshot<Widget> snapshot) {
                        switch (snapshot.connectionState) {
                          case ConnectionState.none:
                            return Center(child: CircularProgressIndicator());
                          case ConnectionState.waiting:
                            return Center(child: CircularProgressIndicator());
                          default:
                            if (snapshot.hasError)
                              return Center(child: CircularProgressIndicator());
                            else
                              return snapshot.data;
                        }
                      },
                    )
                ),
              ),

              Card(
                elevation: 2.0,
                color: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8.0),
                ),
                child: Container(
                  width: 320.0,
                  height: 50.0,
                  child: Column(
                    children: <Widget>[
                      Padding(
                        padding: EdgeInsets.only(top: 0.0, bottom: 0.0, left: 10.0, right: 5.0),
                        child: TextFormField(
                          focusNode: myFocusNodeBuscar,
                          controller: buscarController,
                          keyboardType: TextInputType.text,
                          style: TextStyle(
                              fontFamily: "WorkSansSemiBold",
                              fontSize: 16.0,
                              color: Colors.black
                          ),
                          decoration: InputDecoration(
                              border: InputBorder.none,
                              hintText: "Buscar Produto",
                              hintStyle: TextStyle(fontFamily: "WorkSansSemiBold", fontSize: 17.0),
                              suffixIcon: MaterialButton(
                                highlightColor: Colors.transparent,
                                splashColor: Colors.blue,
                                child: Padding(
                                  padding: EdgeInsets.only(left: 100),
                                  child: Icon(
                                    Icons.search,
                                    color: Colors.black,
                                    size: 22.0,
                                  ),
                                ),
                                onPressed: (){
                                },
                              )
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              FutureBuilder <List<Produto>>(
                future: _fetchProdutos(),
                builder: (context, snapshot){
                  switch (snapshot.connectionState) {
                    case ConnectionState.none:
                      return Center(child: CircularProgressIndicator());
                    case ConnectionState.waiting:
                      return Center(child: CircularProgressIndicator());
                    default:
                      if (snapshot.hasError)
                        return Center(child: CircularProgressIndicator());
                      else
                      return Expanded(child: _listViewProdutos(snapshot.data));
                  }
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
  ListView _listViewProdutos(List<Produto> produtos){
    return ListView.builder(
      scrollDirection: Axis.vertical,
          shrinkWrap: true,
          //controller: controller,
          itemCount: produtos.length,
          physics: BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics()),
          itemBuilder: (context, index) {
            double scale = 1.0;
            if (topContainer > 0.5) {
              scale = index + 0.5 - topContainer;
              if (scale < 0) {
                scale = 0;
              } else if (scale > 1) {
                scale = 1;
              }
            }
            return _buildCardProduto(produtos[index]);
          }
      );
  }
  Widget _buildCardProduto(Produto produto){
    return Container(
        height: 120,
        margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 5),
        decoration: BoxDecoration(
            borderRadius: BorderRadius.all(Radius.circular(20.0)),
            color: Colors.white,
            boxShadow: [
              BoxShadow(
                  color: Colors.black.withAlpha(100),
                  blurRadius: 10.0
              ),
            ]),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10.0, vertical: 10),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Container(
                    height: 80,
                    width: 80,
                    decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        image: DecorationImage(
                            fit: BoxFit.cover,
                            image: NetworkImage( API.pathImage + produto.imagem)
                        )
                    ),
                  ),

                ],

              ),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 5),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(
                    produto.nome,
                    style: const TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.bold),
                  ),
                  Text(
                    produto.unidade == "U" ? "Unidade": "100g",
                    style: const TextStyle(
                        fontSize: 10,
                        fontWeight: FontWeight.bold),
                  ),
                  Divider(),
                  Row(
                    children: <Widget>[
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(produto.valorPromocional == "null" ?
                          "--R\$ ${produto.valor}--": "R\$ ${produto.valor}",
                            style: const TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.bold),
                          ),
                          Text(produto.valorPromocional != "null" ?
                          "R\$ ${produto.valorPromocional}": "" ,
                            style: const TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.bold),
                          ),
                        ],
                      ),
                    ],
                  ),
                ],
              ),
              Expanded(
                child: Container(),
              ),

              Padding(
                padding: EdgeInsets.only(left: 5),
                child: Column(
                  children: <Widget>[
                    SizedBox(
                      height: 35,
                      width: 115,
                      child: CustomNumberPicker(
                        min: 0,
                        max: 1000,
                        onChange: (number) {
                          print("Mudei");
                        },
                      ),
                    ),
                    RaisedButton(
                      onPressed: () {},
                      child: const Text('Adicionar', style: TextStyle(fontSize: 16)),
                    ),
                  ],
                ),
              ),

            ],
          ),
        )
    );
  }
}

