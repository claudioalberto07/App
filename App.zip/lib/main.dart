import 'dart:convert';
import 'package:apploja/ui/HomePage.dart';
import 'package:apploja/ui/loginPage.dart';
import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'ui/Start.dart';

final storage = FlutterSecureStorage();

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  Future<String> checkHome() async{
    String jwt = await storage.read(key: "jwt");
    if(jwt == null) return "";
    return jwt;
  }
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "Comprou, Chegou",
      theme: ThemeData(
        primarySwatch:Colors.blue
      ),
      home:  FutureBuilder(
        future: checkHome(),
        builder: (context, snapshot){
          if(!snapshot.hasData)
            return CircularProgressIndicator();
          if(snapshot.data != "") {
            var str = snapshot.data;
            var jwt = str.split(".");

            if(jwt.length !=3) {
              return PageLogin();
            }else{
              var payload = json.decode(ascii.decode(base64.decode(base64.normalize(jwt[1]))));
              if(DateTime.fromMillisecondsSinceEpoch(payload["expires"]*1000).isAfter(DateTime.now())) {
                return HomePage(jwt: snapshot.data);
              } else
                return PageLogin();
            }
          } else {
            return PageLogin();
          }
        },
      ),
    );
  }
}
