import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class CustomAppBarItem{
  IconData icon;
  bool hasNotification;
  CustomAppBarItem({this.icon, this.hasNotification});
}

class CustomBottomAppBar extends StatefulWidget{
  final ValueChanged<int> onTabSelected;
  final List<CustomAppBarItem> items;

  CustomBottomAppBar({this.items, this.onTabSelected});

  @override
  _CustomBottomAppBarState createState() => _CustomBottomAppBarState();
}

class _CustomBottomAppBarState extends State<CustomBottomAppBar> {
  int _selectIndex = 0;
  void _updateIndex(int index){
    widget.onTabSelected(index);
    setState(() {
      _selectIndex = index;
    });
  }
  Widget _buildTabIcon({int index, CustomAppBarItem item, ValueChanged<int> onPressed}){
    return Expanded(
      child: SizedBox(
        height: 60.0,
        child: Material(
          type: MaterialType.transparency,
          child: InkWell(
            onTap: ()=> onPressed(index),
            child: Icon(
              item.icon,
              color: _selectIndex == index ? Colors.blue : Colors.grey,
              size: 24.0,
            ),
          ),
        ),
      ),
    );

}

  @override
  Widget build(BuildContext context) {
    List<Widget> items = List.generate(widget.items.length, (int index){
      return _buildTabIcon(
        index: index,
        item: widget.items[index],
        onPressed: _updateIndex
      );
    });
    return BottomAppBar(
        shape: CircularNotchedRectangle(),
        color: Colors.white,
        child: Container(
          height: 50.0,
          child: Row(
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: items
          ),
        ),
      );
  }
}