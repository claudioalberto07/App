import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class CustomNumberPicker extends StatefulWidget {
  final int min;
  final int max;
  final Function onChange;

  const CustomNumberPicker({Key key, this.min = 0, this.max = 10, this.onChange}) : super(key: key);
  @override
  _CustomNumberPickerState createState() => _CustomNumberPickerState();
}

class _CustomNumberPickerState extends State<CustomNumberPicker> {
  int _currentValue = 0;
  TextEditingController _currentValueController = new TextEditingController();
  final FocusNode _currentValueFocus = new FocusNode();

  @override
  void initState(){
    super.initState();
    _currentValueController.text = "0";
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.black26,
        borderRadius: BorderRadius.all(Radius.circular(16.0)),
      ),
      child: Row(
        children: <Widget>[
          IconButton(
            iconSize: 14,
            icon: Icon(Icons.remove),
            onPressed: () {
              int _currentValue = int.parse(_currentValueController.text);

              if (_currentValue > widget.min)
                setState(() {
                  _currentValue--;
                  _currentValueController.text = _currentValue.toString();
                });
                //setState(() => _currentValue--);
              widget.onChange(_currentValue);
            },
          ),
          Expanded(
            child:TextFormField(
              textAlign: TextAlign.center,
              decoration: InputDecoration(
                  contentPadding: EdgeInsets.all(5.0),
                  border: OutlineInputBorder(
                    //borderRadius: BorderRadius.circular(5)
                  )
              ),
              controller: _currentValueController,
              keyboardType: TextInputType.number,
              inputFormatters: <TextInputFormatter>[
                WhitelistingTextInputFormatter.digitsOnly
              ],
            ),
          ),


/*          Text(
            "$_currentValue",
            style: TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 16,
              color: _currentValue > 0 ? Colors.white : Colors.white.withOpacity(0.5),
            ),
          ),*/
          IconButton(
            iconSize: 14,
            icon: Icon(
              Icons.add,
            ),
            onPressed: () {
              int _currentValue = int.parse(_currentValueController.text);
              if (_currentValue < widget.max)
                setState(() {
                  _currentValue++;
                  _currentValueController.text = _currentValue.toString();
                });
              widget.onChange(_currentValue);
            },
          ),
        ],
      ),
    );
  }
}